
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

public class MakePayment extends JFrame implements ActionListener {

    // Components of the form
    private Container c;
    private JLabel title;
    private JLabel amountLabel;
    private JTextField amountTextField;
    private JLabel paymentMethodLabel;
    private JComboBox<String> paymentMethodComboBox;
    private JLabel cardNumberLabel;
    private JTextField cardNumberTextField;
    private JButton payButton;
    private JButton resetButton;
    private JTextArea resultArea;
    private JButton back;

    // Constructor to initialize the components
    public MakePayment() {
        setTitle("Make Payment");
        setBounds(300, 90, 900, 600);
       // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Make Payment");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(300, 30);
        title.setLocation(300, 30);
        c.add(title);

        amountLabel = new JLabel("Amount");
        amountLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        amountLabel.setSize(100, 20);
        amountLabel.setLocation(100, 100);
        c.add(amountLabel);

        amountTextField = new JTextField();
        amountTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        amountTextField.setSize(200, 20);
        amountTextField.setLocation(220, 100);
        c.add(amountTextField);

        paymentMethodLabel = new JLabel("Payment Method");
        paymentMethodLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        paymentMethodLabel.setSize(200, 20);
        paymentMethodLabel.setLocation(100, 150);
        c.add(paymentMethodLabel);

        String[] paymentMethods = {"Credit Card", "Debit Card", "Net Banking", "UPI"};
        paymentMethodComboBox = new JComboBox<>(paymentMethods);
        paymentMethodComboBox.setFont(new Font("Arial", Font.PLAIN, 15));
        paymentMethodComboBox.setSize(200, 20);
        paymentMethodComboBox.setLocation(320, 150);
        c.add(paymentMethodComboBox);

        cardNumberLabel = new JLabel("Card Number");
        cardNumberLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        cardNumberLabel.setSize(150, 20);
        cardNumberLabel.setLocation(100, 200);
        c.add(cardNumberLabel);

        cardNumberTextField = new JTextField();
        cardNumberTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        cardNumberTextField.setSize(200, 20);
        cardNumberTextField.setLocation(270, 200);
        c.add(cardNumberTextField);

        payButton = new JButton("Pay");
        payButton.setFont(new Font("Arial", Font.PLAIN, 15));
        payButton.setSize(100, 20);
        payButton.setLocation(250, 250);
        payButton.addActionListener(this);
        c.add(payButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Arial", Font.PLAIN, 15));
        resetButton.setSize(100, 20);
        resetButton.setLocation(400, 250);
        resetButton.addActionListener(this);
        c.add(resetButton);

        resultArea = new JTextArea();
        resultArea.setFont(new Font("Arial", Font.PLAIN, 15));
        resultArea.setSize(600, 200);
        resultArea.setLocation(150, 300);
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);
        c.add(resultArea);
        
        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 15));
        back.setSize(100, 20);
        back.setLocation(380, 520);
        back.addActionListener(this);
        c.add(back);
        
        this.setVisible(true);
    }

    // Handle button clicks
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == payButton) {
// Get amount and payment method
            String amountStr = amountTextField.getText();
            String paymentMethod = (String) paymentMethodComboBox.getSelectedItem();

            // Validate amount
            if (amountStr.equals("")) {
                JOptionPane.showMessageDialog(this, "Please enter amount");
                return;
            }
            double amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Please enter a valid amount");
                return;
            }

            String cardNumber = cardNumberTextField.getText();
            // Validate card number for credit and debit cards
            if (paymentMethod.equals("Credit Card") || paymentMethod.equals("Debit Card")) {
                if (cardNumber.equals("")) {
                    JOptionPane.showMessageDialog(this, "Please enter card number");
                    return;
                }
                if (!cardNumber.matches("[0-9]{16}")) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid card number");
                    return;
                }
            }

            // Make payment
            String result = makePayment(amount, paymentMethod, cardNumber);

            // Display result
            resultArea.setText(result);

        } else if (e.getSource() == resetButton) {
            // Clear form
            amountTextField.setText("");
            paymentMethodComboBox.setSelectedIndex(0);
            cardNumberTextField.setText("");
            resultArea.setText("");
        }else if(e.getSource() == back){
            this.dispose();
        }
    }

// Method to make payment
    private String makePayment(double amount, String paymentMethod, String cardNumber) {
        // Code to make payment goes here
        LocalDate date = LocalDate.now();
        Instant instant = date.atStartOfDay(ZoneId.systemDefault()).toInstant();
        Date d = Date.from(instant);

        File file = new File("payments.txt");
        if (file.exists()) {
            ArrayList<Payment> list = FileManager.retrievePaymentData();
            Payment payment = new Payment(d,amount,paymentMethod,cardNumber);
            list.add(payment);
            
            FileManager.savePaymentData(list);
        }else{
           ArrayList<Payment> list = new ArrayList<>(); 
           Payment payment = new Payment(d,amount,paymentMethod,cardNumber);
            list.add(payment);
            
            FileManager.savePaymentData(list);
        }
        return "Payment of $" + amount + " made using " + paymentMethod;
    }

//    public static void main(String[] args) {
//        MakePayment frame = new MakePayment();
//        frame.setVisible(true);
//    }
}
