
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentDashboard {

    JFrame frame;
    JPanel panel;
    JLabel title;
    JButton makeApplicationButton;
    JButton checkAvailableRoomsButton;
    JButton trackApplicationButton;
    JButton makePaymentButton;
    JButton logoutButton;

    public StudentDashboard() {
        // Initialize frame
        // Initialize components
        frame = new JFrame("Student Dashboard");
        panel = new JPanel(new GridBagLayout());
        title = new JLabel("Welcome to Hostel Management System");
        makeApplicationButton = new JButton("Make Hostel Application");
        checkAvailableRoomsButton = new JButton("Check Available Hostel Rooms");
        trackApplicationButton = new JButton("Track Personal Application Status");
        makePaymentButton = new JButton("Make Payment");
        logoutButton = new JButton("Logout");

        // Add components to panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(title, gbc);
        gbc.gridy = 1;
        panel.add(makeApplicationButton, gbc);
        gbc.gridy = 2;
        panel.add(checkAvailableRoomsButton, gbc);
        gbc.gridy = 3;
        panel.add(trackApplicationButton, gbc);
        gbc.gridy = 4;
        panel.add(makePaymentButton, gbc);
        gbc.gridy = 5;
        panel.add(logoutButton, gbc);

        makeApplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MakeHostelApplication();
            }
        });

        checkAvailableRoomsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CheckAvailableHostelRooms();
            }
        });

        trackApplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TrackPersonalApplication();
            }
        });

        makePaymentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MakePayment();
            }
        });
        
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              frame.dispose();
              System.exit(0);  
            }
        });

        frame.add(panel);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
      //  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }

//    public static void main(String[] args) {
//        new StudentDashboard();
//    }
}
