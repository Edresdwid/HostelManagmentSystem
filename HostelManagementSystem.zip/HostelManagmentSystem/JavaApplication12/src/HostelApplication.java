
import java.util.Date;

public class HostelApplication {
    private String studentName;
    private String roomPerference;
    private String gender;
    private String year;
    private String course;
    private int roomNumber;
    private Date applicationDate;
    private String status;

    public HostelApplication(String studentName, int roomNumber, Date applicationDate,String status,String roomPerference,String gender,
            String year, String course
            ) {
        this.studentName = studentName;
        this.roomNumber = roomNumber;
        this.applicationDate = applicationDate;
        this.status = status;
        this.roomPerference = roomPerference;
        this.gender = gender;
        this.year = year;
        this.course = course;
    }
    
    public String getRoomPerference(){
        return roomPerference;
    }
    
    public String getGender(){
        return gender;
    }
    
    public String getYear(){
        return year;
    }
    
    public String getCourse(){
        return course;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public Date getApplicationDate() {
        return applicationDate;
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String status){
        this.status = status;
    }

//    public void manageApplication() {
//        // Student hostel application management logic
//    }
//
//    public void trackRecord() {
//        // Student hostel application tracking logic
//    }
//
//    public void historicalRecord() {
//        // Student historical application record logic
//    }
}
