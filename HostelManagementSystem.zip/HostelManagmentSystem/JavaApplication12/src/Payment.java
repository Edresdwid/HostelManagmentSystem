
import java.util.Date;

public class Payment {
    private Date paymentDate;
    private double amount;
    private String paymentMethod;
    private String cardNumber;

    public Payment(Date paymentDate, double amount,String paymentMethod,String cardNumber) {
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.cardNumber = cardNumber;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public double getAmount() {
        return amount;
    }
    
    public String getPaymentMethod(){
        return paymentMethod;
    }
    
    public String getCardNumber(){
        return cardNumber;
    }

//    public void makePayment() {
//        // Student payment logic
//    }
}