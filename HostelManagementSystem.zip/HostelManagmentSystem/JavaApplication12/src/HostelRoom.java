public class HostelRoom {
    private int roomNumber;
    private int occupancy;
    private double price;
    private String availability;

    public HostelRoom(int roomNumber, int occupancy,double price,String availability) {
        this.roomNumber = roomNumber;
        this.occupancy = occupancy;
        this.price = price;
        this.availability = availability;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getOccupancy() {
        return occupancy;
    }

    public double getPrice() {
        return price;
    }
    
    public String getAvailability(){
        return this.availability;
    }
    
    public void setOccupancy(int occupancy){
        this.occupancy = occupancy;
    }
    
    public void setPrice(double price){
        this.price = price;
    }
    
    public void setAvailability(String availability){
        this.availability = availability;
    }

//    public void addRoom() {
//        // Hostel room addition logic
//    }
//
//    public void updateRoom() {
//        // Hostel room update logic
//    }
//
//    public void readRoom() {
//        // Hostel room read logic
//    }
//
//    public void deleteRoom() {
//        // Hostel room deletion logic
//    }
}
