
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GenerateReport extends JFrame {

    private JLabel titleLabel;
    private JButton incomeButton;
    private JButton roomAvailabilityButton;
    private JButton backButton;

    public GenerateReport() {

        // Set up the frame
        setTitle("Generate Report");
        setSize(400, 300);
       // setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        // Add components
        titleLabel = new JLabel("Select a report to generate:");
        incomeButton = new JButton("Monthly Income Report");
        roomAvailabilityButton = new JButton("Room Availability Report");
        backButton = new JButton("Back");

        // Add action listeners to buttons
        incomeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Generate monthly income report
                // Code for generating report goes here
                //ArrayList<HostelRoom> hostelRooms = FileManager.readHostelRoomsFromFile();
                ArrayList<Payment> payment = FileManager.retrievePaymentData();

                // Generate the report
                StringBuilder report = new StringBuilder();
                report.append(String.format("%-15s %s%n", "Month:", "Payment:"));
                for (Payment p : payment) {
                    report.append(String.format("%-25s %s%n", p.getPaymentDate().getMonth(), p.getAmount()));
                }

                // Display the report in a dialog box
                JTextArea reportTextArea = new JTextArea(report.toString());
                reportTextArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(reportTextArea);
                scrollPane.setPreferredSize(new Dimension(500, 300));
                JOptionPane.showMessageDialog(null, scrollPane, "Room Information Report", JOptionPane.PLAIN_MESSAGE);
              //  JOptionPane.showMessageDialog(null, "Monthly Income Report generated!");
            }
        });

        roomAvailabilityButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Generate room availability report
                // Code for generating report goes here
                ArrayList<HostelRoom> hostelRooms = FileManager.readHostelRoomsFromFile();

                // Generate the report
                StringBuilder report = new StringBuilder();
                report.append(String.format("%-15s %-15s %-15s %s%n", "Number:", "Occupancy:", "Price:", "Availability:"));
                for (HostelRoom room : hostelRooms) {
                    if(room.getAvailability().equalsIgnoreCase("Available")){
                        report.append(String.format("%-25s %-20s  %-15s %s%n", room.getRoomNumber(), room.getOccupancy(), room.getPrice(), room.getAvailability()));
                    }                   
                }

                // Display the report in a dialog box
                JTextArea reportTextArea = new JTextArea(report.toString());
                reportTextArea.setEditable(false);
                JScrollPane scrollPane = new JScrollPane(reportTextArea);
                scrollPane.setPreferredSize(new Dimension(500, 300));
                JOptionPane.showMessageDialog(null, scrollPane, "Room Information Report", JOptionPane.PLAIN_MESSAGE);
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Go back to admin dashboard
                dispose(); // Close current window
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.setVisible(true);
            }
        });

        // Add components to the frame
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 0, 10, 0);
        add(titleLabel, gbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 0, 0);
        add(incomeButton, gbc);

        gbc.gridy = 2;
        add(roomAvailabilityButton, gbc);

        gbc.gridy = 3;
        gbc.insets = new Insets(10, 0, 10, 0);
        add(backButton, gbc);

        // Set the frame to be visible
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }

//    public static void main(String args[]) {
//        new GenerateReport();
//    }
}
