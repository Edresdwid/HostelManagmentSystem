import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class HostelRoomCURD extends JFrame implements ActionListener {

    // JFrame Components
    private JLabel titleLabel;
    private JLabel roomNumberLabel;
    private JLabel roomTypeLabel;
    private JLabel priceLabel;
    private JLabel availabilityLabel;
    private JTextField roomNumberTextField;
    private JTextField roomTypeTextField;
    private JTextField priceTextField;
    private JComboBox<String> availabilityComboBox;
    private JButton addButton;
    private JButton updateButton;
    private JButton readButton;
    private JButton deleteButton;
    private JButton back;

     public HostelRoomCURD() {
        super("Hostel Room CRUD");

        // Set layout manager
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        
        // Create and add components
        titleLabel = new JLabel("Hostel Room Information", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, gbc);
        
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        roomNumberLabel = new JLabel("Room Number:", JLabel.RIGHT);
        add(roomNumberLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        roomNumberTextField = new JTextField(10);
        add(roomNumberTextField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        roomTypeLabel = new JLabel("Occupancy:", JLabel.RIGHT);
        add(roomTypeLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        roomTypeTextField = new JTextField(10);
        add(roomTypeTextField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        priceLabel = new JLabel("Price:", JLabel.RIGHT);
        add(priceLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        priceTextField = new JTextField(10);
        add(priceTextField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.EAST;
        availabilityLabel = new JLabel("Availability:", JLabel.RIGHT);
        add(availabilityLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        availabilityComboBox = new JComboBox<>(new String[]{"Available", "Not Available"});
        add(availabilityComboBox, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        addButton = new JButton("Add");
        addButton.addActionListener(this);
        updateButton = new JButton("Update");
        updateButton.addActionListener(this);
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);
        back = new JButton("Back");
        back.addActionListener(this);
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(back);
        add(buttonPanel, gbc);

        // Set window properties
        setSize(600, 400);
        setLocationRelativeTo(null);
      //  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(!roomNumberTextField.getText().isEmpty()||!roomTypeTextField.getText().isEmpty()||!priceTextField.getText().isEmpty()||!availabilityComboBox.getSelectedItem().toString().isEmpty()){
            if (e.getSource() == addButton) {
            
            File file = new File("hostel_rooms.txt");
            if(file.exists()){
                ArrayList<HostelRoom> r = FileManager.readHostelRoomsFromFile();
                r.add(new HostelRoom(Integer.parseInt(roomNumberTextField.getText()), Integer.parseInt(roomTypeTextField.getText()),Double.parseDouble(priceTextField.getText()), availabilityComboBox.getSelectedItem().toString()));
                FileManager.writeHostelRoomsToFile(r);
                JOptionPane.showMessageDialog(null, "Room added successfully", "Information", JOptionPane.INFORMATION_MESSAGE);

            }else{
                ArrayList<HostelRoom> r = new ArrayList<>();
                r.add(new HostelRoom(Integer.parseInt(roomNumberTextField.getText()), Integer.parseInt(roomTypeTextField.getText()),Double.parseDouble(priceTextField.getText()), availabilityComboBox.getSelectedItem().toString()));
                FileManager.writeHostelRoomsToFile(r);
                JOptionPane.showMessageDialog(null, "Room added successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
            
            // Add button code
        } else if (e.getSource() == updateButton) {
            // Update button code
            File file = new File("hostel_rooms.txt");
            if(file.exists()){
                ArrayList<HostelRoom> r = FileManager.readHostelRoomsFromFile();
                //r.add(new HostelRoom(Integer.parseInt(roomNumberTextField.getText()), Integer.parseInt(roomTypeTextField.getText()),Double.parseDouble(priceTextField.getText()), availabilityComboBox.getSelectedItem().toString()));
                FileManager.updateHostelRoom(r, Integer.parseInt(roomNumberTextField.getText()), Integer.parseInt(roomTypeTextField.getText()), Double.parseDouble(priceTextField.getText()), availabilityComboBox.getSelectedItem().toString());
                JOptionPane.showMessageDialog(null, "Room updated successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "No room is existing", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (e.getSource() == back) {
            this.dispose();
            // Read button code
        } else if (e.getSource() == deleteButton) {
            // Delete button code
            File file = new File("hostel_rooms.txt");
            if(file.exists()){
                ArrayList<HostelRoom> r = FileManager.readHostelRoomsFromFile();
                //r.add(new HostelRoom(Integer.parseInt(roomNumberTextField.getText()), Integer.parseInt(roomTypeTextField.getText()),Double.parseDouble(priceTextField.getText()), availabilityComboBox.getSelectedItem().toString()));
                FileManager.deleteHostelRoom(r, Integer.parseInt(roomNumberTextField.getText()));
                JOptionPane.showMessageDialog(null, "Room deleted successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "No room is existing", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        }else{
            JOptionPane.showMessageDialog(null, "No row is selected", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
        
    }

    public static void main(String[] args) {
        new HostelRoomCURD();
    }
}
