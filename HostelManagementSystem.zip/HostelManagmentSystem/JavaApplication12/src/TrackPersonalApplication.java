
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import javax.swing.*;

public class TrackPersonalApplication extends JFrame implements ActionListener {
// Components of the form

    private Container c;
    private JLabel title;
    private JLabel studentIdLabel;
    private JTextField studentIdField;
    private JButton searchButton;
    private JButton resetButton;
    private JTextArea resultArea;
    private JButton back;

// Constructor to initialize the components
    public TrackPersonalApplication() {
        setTitle("Track Personal Application");
        setBounds(300, 90, 900, 600);
        // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Track Personal Application");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(500, 30);
        title.setLocation(200, 30);
        c.add(title);

        studentIdLabel = new JLabel("Student Name");
        studentIdLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        studentIdLabel.setSize(200, 20);
        studentIdLabel.setLocation(100, 100);
        c.add(studentIdLabel);

        studentIdField = new JTextField();
        studentIdField.setFont(new Font("Arial", Font.PLAIN, 15));
        studentIdField.setSize(200, 20);
        studentIdField.setLocation(250, 100);
        c.add(studentIdField);

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Arial", Font.PLAIN, 15));
        searchButton.setSize(100, 20);
        searchButton.setLocation(250, 150);
        searchButton.addActionListener(this);
        c.add(searchButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Arial", Font.PLAIN, 15));
        resetButton.setSize(100, 20);
        resetButton.setLocation(400, 150);
        resetButton.addActionListener(this);
        c.add(resetButton);

        resultArea = new JTextArea();
        resultArea.setFont(new Font("Arial", Font.PLAIN, 15));
        resultArea.setSize(600, 300);
        resultArea.setLocation(150, 200);
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);
        c.add(resultArea);

        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 15));
        back.setSize(100, 20);
        back.setLocation(380, 520);
        back.addActionListener(this);
        c.add(back);

        this.setVisible(true);
    }

// Handle button clicks
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            // Get the student ID from the input field
            String studentId = studentIdField.getText();

            // Perform the search and display the results
            String results = searchPersonalApplication(studentId);
            resultArea.setText(results);
        } else if (e.getSource() == resetButton) {
            // Reset the form
            studentIdField.setText("");
            resultArea.setText("");
        } else if (e.getSource() == back) {
            this.dispose();
        }
    }

// Perform the search for personal application data and historical record based on the given student ID
    private String searchPersonalApplication(String studentId) {
        File file = new File("hostel_applications.txt");
        if (file.exists()) {
            ArrayList<HostelApplication> ha = FileManager.readHostelApplicationsFromFile();
            for (HostelApplication hostelapp : ha) {
                if (hostelapp.getStudentName().equalsIgnoreCase(studentId)) {
                    return hostelapp.getStatus();
                }
            }
            return "No Application with Student name: " + studentId;
        }
        return "Results for student ID " + studentId + " will be displayed here.";
    }

//    public static void main(String args[]) {
//        new TrackPersonalApplication();
//    }
}
