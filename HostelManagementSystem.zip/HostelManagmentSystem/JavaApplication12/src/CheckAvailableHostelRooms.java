
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class CheckAvailableHostelRooms extends JFrame implements ActionListener {

    // Components of the form
    private Container c;
    private JLabel title;
    private JTextArea resultArea;
    private JTable roomTable;
    private JScrollPane scrollPane;
    private JButton generateReportButton;
    private JButton back;

    // Constructor to initialize the components
    public CheckAvailableHostelRooms() {
        setTitle("Check Available Hostel Rooms");
        setBounds(300, 90, 900, 600);
        // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Check Available Hostel Rooms");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(500, 30);
        title.setLocation(200, 30);
        c.add(title);

        // Create table header
        String[] columns = {"Room Number", "Occupancy", "Price", "Availability"};

        // Get room data from FileManager class
        File file = new File("hostel_rooms.txt");
        Object[][] data = null;
        if (file.exists()) {
            ArrayList<HostelRoom> rooms = FileManager.readHostelRoomsFromFile();
            // Create table data
            data = new Object[rooms.size()][4];
            for (int i = 0; i < rooms.size(); i++) {
                data[i][0] = rooms.get(i).getRoomNumber();
                data[i][1] = rooms.get(i).getOccupancy();
                data[i][2] = rooms.get(i).getPrice();
                data[i][3] = rooms.get(i).getAvailability();
            }
        } else {
            data = new Object[0][4];
        }

        // Create table and scroll pane
        roomTable = new JTable(data, columns);
        roomTable.setFont(new Font("Arial", Font.PLAIN, 15));
        roomTable.setRowHeight(30);
        scrollPane = new JScrollPane(roomTable);
        scrollPane.setBounds(50, 100, 800, 400);
        c.add(scrollPane);

        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 15));
        back.setSize(100, 20);
        back.setLocation(380, 520);
        c.add(back);
        
        JFrame frame = this;
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        
        this.setVisible(true);
    }

//    // Handle button clicks
    public void actionPerformed(ActionEvent e) {
    }

//    //Main method to create the GUI
//    public static void main(String[] args) {
//        CheckAvailableHostelRooms frame = new CheckAvailableHostelRooms();
//        frame.setVisible(true);
//    }
}
