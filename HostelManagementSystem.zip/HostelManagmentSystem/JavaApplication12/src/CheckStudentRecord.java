
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class CheckStudentRecord extends JFrame implements ActionListener {

    // UI components
    private JTextField searchField;
    private JTable recordTable;
    private JButton searchButton;
    private JButton back;

    public CheckStudentRecord() {
        // Set up the UI
        setTitle("Check Student Record");
        setSize(700, 500);
        // setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the UI components
        JPanel searchPanel = new JPanel();
        JLabel searchLabel = new JLabel("Search Student Record:");
        searchField = new JTextField(20);
        searchButton = new JButton("Search");
        searchButton.addActionListener(this);
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        JPanel recordPanel = new JPanel();
        JLabel recordLabel = new JLabel("Student Record:");
        recordTable = new JTable();
        recordTable.setEnabled(false);
        recordTable.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(recordTable);
        scrollPane.setPreferredSize(new Dimension(600, 350));
        recordPanel.add(recordLabel);
        recordPanel.add(scrollPane);

        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 15));
        back.addActionListener(this);

        // Add the UI components to the frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(searchPanel, BorderLayout.NORTH);
        contentPane.add(recordPanel, BorderLayout.CENTER);

        // Add back button to SOUTH using FlowLayout
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(back);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            // and display it in the recordTable
            String searchQuery = searchField.getText();
            DefaultTableModel model = searchStudentRecord(searchQuery);
            recordTable.setModel(model);
        }else if(e.getSource() == back){
            this.dispose();
        }
    }

    // A sample method to search for the student record in the system
    private DefaultTableModel searchStudentRecord(String searchQuery) {
        // based on the searchQuery and return the record as a DefaultTableModel
        File file = new File("hostel_applications.txt");
        if (file.exists()) {
            ArrayList<HostelApplication> list = FileManager.readHostelApplicationsFromFile();
            ArrayList<User> users = FileManager.readUsersFromFile();
            if (users.stream().anyMatch(value -> value.getName().equalsIgnoreCase(searchQuery))) {
                String[] columnNames = {"Name", "Room Number", "Room Preference", "Gender", "Year", "Course", "Email"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0);
                for (HostelApplication ha : list) {
                    String email = "";
                    String name = "";
                    for (User user : users) {
                        if (user.getName().equalsIgnoreCase(ha.getStudentName())) {
                            email = user.getEmail();
                            name = user.getName();
                        }
                    }
                    Object[] rowData = {name, ha.getRoomNumber(), ha.getRoomPerference(), ha.getGender(), ha.getYear(), ha.getCourse(), email};
                    model.addRow(rowData);
                }
                return model;
            } else {
                String[] columnNames = {"No Data For This Student"};
                DefaultTableModel model = new DefaultTableModel(columnNames, 0);
                return model;
            }

        } else {
            String[] columnNames = {"No Data"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            return model;
        }
    }

//    public static void main(String[] args) {
//        // Create and display the UI
//        CheckStudentRecord ui = new CheckStudentRecord();
//        ui.setVisible(true);
//    }
}
