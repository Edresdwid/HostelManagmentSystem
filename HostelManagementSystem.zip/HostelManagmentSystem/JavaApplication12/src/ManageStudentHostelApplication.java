
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class ManageStudentHostelApplication extends JFrame {

    // Define the UI components
    private JLabel titleLabel;
    private JTable applicationTable;
    private JButton approveButton;
    private JButton rejectButton;
    private JButton waitlistButton;
    private JButton back;

    public ManageStudentHostelApplication() {

        // Set the title of the window
        setTitle("Manage Student Hostel Application");

        // Set the size of the window
        setSize(600, 400);

        // Set the layout of the window
        setLayout(new BorderLayout());

        // Create a panel to hold the title
        JPanel titlePanel = new JPanel();
        titleLabel = new JLabel("Manage Student Hostel Application");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titlePanel.add(titleLabel);

        File file = new File("hostel_applications.txt");
        Object[][] data = null;
        if (file.exists()) {
            ArrayList<HostelApplication> applications = FileManager.readHostelApplicationsFromFile();
            // Create table data
            data = new Object[applications.size()][3];
            for (int i = 0; i < applications.size(); i++) {
                data[i][0] = applications.get(i).getStudentName();
                data[i][1] = applications.get(i).getRoomPerference();
                data[i][2] = applications.get(i).getStatus();
            }
        } else {
            data = new Object[0][3];
        }
        // Create a panel to hold the application table
        JPanel applicationPanel = new JPanel();
        applicationTable = new JTable(new DefaultTableModel(
                data,
                new String[]{
                    "Student Name", "Room Preference", "Application Status"
                }
        ));
        applicationTable.setPreferredScrollableViewportSize(new Dimension(500, 200));
        applicationTable.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(applicationTable);
        applicationPanel.add(scrollPane);

        // Create a panel to hold the buttons
        JPanel buttonPanel = new JPanel();
        approveButton = new JButton("Approve");
        rejectButton = new JButton("Reject");
        waitlistButton = new JButton("Waitlist");
        back = new JButton("Back");
        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        buttonPanel.add(waitlistButton);
        buttonPanel.add(back);

        // Add the panels to the window
        add(titlePanel, BorderLayout.NORTH);
        add(applicationPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add action listeners to the buttons
        approveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = applicationTable.getSelectedRow(); // table is your JTable object
                DefaultTableModel model = (DefaultTableModel) applicationTable.getModel();
                String name = (String) model.getValueAt(selectedRowIndex, 0); // 0 is the column index of the "name" column
                File file = new File("hostel_applications.txt");
                if (file.exists()) {
                    FileManager.updateHostelApplication(name, "approved");
                    model.setValueAt("approved", selectedRowIndex, 2);
                    JOptionPane.showMessageDialog(null, "Application is approved", "Information", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No application exists", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        rejectButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = applicationTable.getSelectedRow(); // table is your JTable object
                DefaultTableModel model = (DefaultTableModel) applicationTable.getModel();
                String name = (String) model.getValueAt(selectedRowIndex, 0); // 0 is the column index of the "name" column
                File file = new File("hostel_applications.txt");
                if (file.exists()) {
                    FileManager.updateHostelApplication(name, "rejected");
                    model.setValueAt("rejected", selectedRowIndex, 2);
                    JOptionPane.showMessageDialog(null, "Application is rejected", "Information", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No application exists", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        waitlistButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = applicationTable.getSelectedRow(); // table is your JTable object
                DefaultTableModel model = (DefaultTableModel) applicationTable.getModel();
                String name = (String) model.getValueAt(selectedRowIndex, 0); // 0 is the column index of the "name" column
                File file = new File("hostel_applications.txt");
                if (file.exists()) {
                    FileManager.updateHostelApplication(name, "pending");
                    model.setValueAt("pending", selectedRowIndex, 2);
                    JOptionPane.showMessageDialog(null, "Holding application in waitlist", "Information", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No application exists", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        JFrame frame = this;
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              frame.dispose();
            }
        });

        // Set the window to be visible
        setVisible(true);
    }

//    public static void main(String[] args) {
//        ManageStudentHostelApplication app = new ManageStudentHostelApplication();
//    }
}
