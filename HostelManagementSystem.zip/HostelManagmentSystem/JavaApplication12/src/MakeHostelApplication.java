
import java.awt.Container;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

public class MakeHostelApplication extends JFrame implements ActionListener {

    // Components of the Form
    private Container c;
    private JLabel title;
    private JLabel nameLabel;
    private JTextField nameTextField;
    private JLabel roomPreferenceLabel;
    private JRadioButton singleRoomRadioButton;
    private JRadioButton doubleRoomRadioButton;
    private JLabel genderLabel;
    private JRadioButton maleRadioButton;
    private JRadioButton femaleRadioButton;
    private JLabel yearLabel;
    private JComboBox<String> yearComboBox;
    private JLabel courseLabel;
    private JTextField courseTextField;
    private JCheckBox agreementCheckBox;
    private JButton submitButton;
    private JButton resetButton;
    private JTextArea resultArea;
    private JButton back;

    // constructor, to initialize the components
    public MakeHostelApplication() {
        setTitle("Make Hostel Application");
        setBounds(300, 90, 900, 600);
       // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Hostel Application Form");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(500, 30);
        title.setLocation(250, 30);
        c.add(title);

        nameLabel = new JLabel("Name");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        nameLabel.setSize(100, 20);
        nameLabel.setLocation(100, 100);
        c.add(nameLabel);

        nameTextField = new JTextField();
        nameTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        nameTextField.setSize(190, 20);
        nameTextField.setLocation(200, 100);
        c.add(nameTextField);

        roomPreferenceLabel = new JLabel("Room Preference");
        roomPreferenceLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        roomPreferenceLabel.setSize(200, 20);
        roomPreferenceLabel.setLocation(100, 150);
        c.add(roomPreferenceLabel);

        singleRoomRadioButton = new JRadioButton("Single Room");
        singleRoomRadioButton.setFont(new Font("Arial", Font.PLAIN, 15));
        singleRoomRadioButton.setSelected(true);
        singleRoomRadioButton.setSize(150, 20);
        singleRoomRadioButton.setLocation(270, 150);
        c.add(singleRoomRadioButton);

        doubleRoomRadioButton = new JRadioButton("Double Room");
        doubleRoomRadioButton.setFont(new Font("Arial", Font.PLAIN, 15));
        doubleRoomRadioButton.setSelected(false);
        doubleRoomRadioButton.setSize(150, 20);
        doubleRoomRadioButton.setLocation(420, 150);
        c.add(doubleRoomRadioButton);

        ButtonGroup group = new ButtonGroup();
        group.add(singleRoomRadioButton);
        group.add(doubleRoomRadioButton);

        genderLabel = new JLabel("Gender");
        genderLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        genderLabel.setSize(100, 20);
        genderLabel.setLocation(100, 200);
        c.add(genderLabel);

        maleRadioButton = new JRadioButton("Male");
        maleRadioButton.setFont(new Font("Arial", Font.PLAIN, 15));
        maleRadioButton.setSelected(true);
        maleRadioButton.setSize(80, 20);
        maleRadioButton.setLocation(250, 200);
        c.add(maleRadioButton);

        femaleRadioButton = new JRadioButton("Female");
        femaleRadioButton.setFont(new Font("Arial", Font.PLAIN, 15));
        femaleRadioButton.setSelected(false);
        femaleRadioButton.setSize(100, 20);
        femaleRadioButton.setLocation(350, 200);
        c.add(femaleRadioButton);

        group = new ButtonGroup();
        group.add(maleRadioButton);
        group.add(femaleRadioButton);

        yearLabel = new JLabel("Year");
        yearLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        yearLabel.setSize(100, 20);
        yearLabel.setLocation(100, 250);
        c.add(yearLabel);

        String[] year = {"First Year",
             "Second Year", "Third Year", "Fourth Year"};
        yearComboBox = new JComboBox<>(year);
        yearComboBox.setFont(new Font("Arial", Font.PLAIN, 15));
        yearComboBox.setSize(150, 20);
        yearComboBox.setLocation(250, 250);
        c.add(yearComboBox);

        courseLabel = new JLabel("Course");
        courseLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        courseLabel.setSize(100, 20);
        courseLabel.setLocation(100, 300);
        c.add(courseLabel);

        courseTextField = new JTextField();
        courseTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        courseTextField.setSize(190, 20);
        courseTextField.setLocation(250, 300);
        c.add(courseTextField);

        agreementCheckBox = new JCheckBox("I agree to the terms and conditions");
        agreementCheckBox.setFont(new Font("Arial", Font.PLAIN, 15));
        agreementCheckBox.setSize(300, 20);
        agreementCheckBox.setLocation(100, 350);
        c.add(agreementCheckBox);

        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.PLAIN, 15));
        submitButton.setSize(100, 20);
        submitButton.setLocation(100, 400);
        submitButton.addActionListener(this);
        c.add(submitButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Arial", Font.PLAIN, 15));
        resetButton.setSize(100, 20);
        resetButton.setLocation(220, 400);
        resetButton.addActionListener(this);
        c.add(resetButton);
        
          back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 15));
        back.setSize(100, 20);
        back.setLocation(150, 450);
        back.addActionListener(this);
        c.add(back);

        resultArea = new JTextArea();
        resultArea.setFont(new Font("Arial", Font.PLAIN, 15));
        resultArea.setSize(300, 200);
        resultArea.setLocation(550, 200);
        resultArea.setLineWrap(true);
        c.add(resultArea);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            String data = "Name: " + nameTextField.getText() + "\n"
                    + "Room Preference: " + (singleRoomRadioButton.isSelected() ? "Single Room" : "Double Room") + "\n"
                    + "Gender: " + (maleRadioButton.isSelected() ? "Male" : "Female") + "\n"
                    + "Year: " + (String) yearComboBox.getSelectedItem() + "\n"
                    + "Course: " + courseTextField.getText() + "\n";
            resultArea.setText(data);
            
            LocalDate date = LocalDate.now();
            Instant instant = date.atStartOfDay(ZoneId.systemDefault()).toInstant();
            Date d = Date.from(instant);
            
            ArrayList<HostelRoom> hr = FileManager.readHostelRoomsFromFile();
                int roomNumber = 0;
                for (HostelRoom room : hr) {
                    if (room.getAvailability().equalsIgnoreCase("Available")) {
                        roomNumber = room.getRoomNumber();
                    }
                }
                
                ArrayList<HostelApplication> ha = new ArrayList<>();
            
            File file = new File("hostel_applications.txt");
            if (file.exists()) {             
                ha = FileManager.readHostelApplicationsFromFile();
                HostelApplication app = new HostelApplication(nameTextField.getText(), roomNumber, d,"pending", singleRoomRadioButton.isSelected() ? "Single Room" : "Double Room",
                        maleRadioButton.isSelected() ? "Male" : "Female", (String) yearComboBox.getSelectedItem(), courseTextField.getText()
                );
                ha.add(app);
                FileManager.writeHostelApplicationsToFile(ha);
                JOptionPane.showMessageDialog(null, "Application Sumbited Successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
            }else{
                HostelApplication app = new HostelApplication(nameTextField.getText(), roomNumber, d,"pending", singleRoomRadioButton.isSelected() ? "Single Room" : "Double Room",
                        maleRadioButton.isSelected() ? "Male" : "Female", (String) yearComboBox.getSelectedItem(), courseTextField.getText()
                );
                ha.add(app);
                FileManager.writeHostelApplicationsToFile(ha);
                JOptionPane.showMessageDialog(null, "Application Sumbited Successfully", "Information", JOptionPane.INFORMATION_MESSAGE);
            }

        } else if (e.getSource() == resetButton) {
            nameTextField.setText("");
            singleRoomRadioButton.setSelected(true);
            doubleRoomRadioButton.setSelected(false);
            maleRadioButton.setSelected(true);
            femaleRadioButton.setSelected(false);
            yearComboBox.setSelectedIndex(0);
            courseTextField.setText("");
            agreementCheckBox.setSelected(false);
            resultArea.setText("");
        }else if(e.getSource() == back){
            this.dispose();
        }
    }

//    public static void main(String[] args) {
//        MakeHostelApplication application = new MakeHostelApplication();
//    }
}
