
import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileManager {

    private static final String USER_FILE_NAME = "users.txt";
    private static final String HOSTEL_ROOM_FILE_NAME = "hostel_rooms.txt";
    private static final String HOSTEL_APPLICATION_FILE_NAME = "hostel_applications.txt";
    private static final String PAYMENT_FILE_NAME = "payments.txt";
    private static final String REPORT_FILE_NAME = "reports.txt";

    public static ArrayList<User> readUsersFromFile() {
        ArrayList<User> users = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(USER_FILE_NAME));
            String line = reader.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                String email = parts[1];
                String password = parts[2];
                String userType = parts[3];
                if (userType.equals("admin")) {
                    users.add(new Admin(name, email, password));
                } else if (userType.equals("student")) {
                    users.add(new Student(name, email, password));
                }
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading users file: " + e.getMessage());
        }
        return users;
    }

    public static void writeUsersToFile(ArrayList<User> users) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE_NAME));
            for (User user : users) {
                String userType = user instanceof Admin ? "admin" : "student";
                writer.write(user.getName() + "," + user.getEmail() + "," + user.getPassword() + "," + userType);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error writing users file: " + e.getMessage());
        }
    }

    public static ArrayList<HostelRoom> readHostelRoomsFromFile() {
        ArrayList<HostelRoom> hostelRooms = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(HOSTEL_ROOM_FILE_NAME));
            String line = reader.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                int roomNumber = Integer.parseInt(parts[0]);
                int occupancy = Integer.parseInt(parts[1]);
                double price = Double.parseDouble(parts[2]);
                String availability = parts[3];
                hostelRooms.add(new HostelRoom(roomNumber, occupancy, price,availability));
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading hostel rooms file: " + e.getMessage());
        }
        return hostelRooms;
    }

    public static void writeHostelRoomsToFile(ArrayList<HostelRoom> hostelRooms) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(HOSTEL_ROOM_FILE_NAME));
            for (HostelRoom room : hostelRooms) {
                writer.write(room.getRoomNumber() + "," + room.getOccupancy() + "," + room.getPrice()+","+room.getAvailability());
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error writing hostel rooms file: " + e.getMessage());
        }
    }

    public static void updateHostelRoom(ArrayList<HostelRoom> hostelRooms, int roomNumber, int occupancy, double price, String availability) {
    for (HostelRoom room : hostelRooms) {
        if (room.getRoomNumber() == roomNumber) {
            room.setOccupancy(occupancy);
            room.setPrice(price);
            room.setAvailability(availability);
            break;
        }
    }
    writeHostelRoomsToFile(hostelRooms);
}

public static void deleteHostelRoom(ArrayList<HostelRoom> hostelRooms, int roomNumber) {
    for (int i = 0; i < hostelRooms.size(); i++) {
        if (hostelRooms.get(i).getRoomNumber() == roomNumber) {
            hostelRooms.remove(i);
            break;
        }
    }
    writeHostelRoomsToFile(hostelRooms);
}

    public static ArrayList<HostelApplication> readHostelApplicationsFromFile() {
        ArrayList<HostelApplication> hostelApplications = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(HOSTEL_APPLICATION_FILE_NAME));
            String line = reader.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                String studentName = parts[0];
                int roomNumber
                        = Integer.parseInt(parts[1]);
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date = dateFormat.parse(parts[2]);
                // Date date = ;
                String status = parts[3];
                String perfer = parts[4];
                String gender = parts[5];
                String year = parts[6];
                String course = parts[7];
                hostelApplications.add(new HostelApplication(studentName, roomNumber, date, status,perfer,gender,year,course));
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading hostel applications file: " + e.getMessage());
        } catch (ParseException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return hostelApplications;
    }

    private static String formatDate(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(date);
        return formattedDate;
    }

    public static void writeHostelApplicationsToFile(ArrayList<HostelApplication> hostelApplications) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(HOSTEL_APPLICATION_FILE_NAME));
            for (HostelApplication application : hostelApplications) {
                String date = FileManager.formatDate(application.getApplicationDate());
                writer.write(application.getStudentName() + "," + application.getRoomNumber() + "," + date + "," + application.getStatus() + "," + application.getRoomPerference()
                      + "," + application.getGender() + "," + application.getYear() + "," + application.getCourse()
                );
                        
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error writing hostel applications file: " + e.getMessage());
        }

    }
    
    public static void updateHostelApplication(String studentName, String newStatus) {
    ArrayList<HostelApplication> hostelApplications = readHostelApplicationsFromFile();
    for (HostelApplication application : hostelApplications) {
        if (application.getStudentName().equals(studentName)) {
            application.setStatus(newStatus);
            break;
        }
    }
    writeHostelApplicationsToFile(hostelApplications);
}

    
        // Saves payment data to a text file
    public static void savePaymentData(ArrayList<Payment> payments) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(PAYMENT_FILE_NAME));

            for (Payment payment : payments) {
                String paymentDateStr = new SimpleDateFormat("yyyy-MM-dd").format(payment.getPaymentDate());
                writer.println(paymentDateStr + "," + payment.getAmount() + "," + payment.getPaymentMethod() + "," + payment.getCardNumber());
            }

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Retrieves payment data from a text file
    public static ArrayList<Payment> retrievePaymentData() {
        ArrayList<Payment> payments = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(PAYMENT_FILE_NAME));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                Date paymentDate = new SimpleDateFormat("yyyy-MM-dd").parse(parts[0]);
                double amount = Double.parseDouble(parts[1]);
                String paymentMethod = parts[2];
                String cardNumber = parts[3];

                Payment payment = new Payment(paymentDate, amount, paymentMethod, cardNumber);
                payments.add(payment);
            }

            reader.close();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return payments;
    }
}
