public class Student extends User {
    public Student(String name, String email, String password) {
        super(name, email, password);
    }

    @Override
    public void login() {
        // Student login logic
    }

    @Override
    public void logout() {
        // Student logout logic
    }
}