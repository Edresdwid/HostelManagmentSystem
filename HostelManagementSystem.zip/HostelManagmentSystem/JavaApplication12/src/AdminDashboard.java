import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard {
    private JFrame frame;
    private JPanel panel;
    private JLabel welcomeLabel;
    private JButton manageRoomsBtn;
    private JButton manageApplicationsBtn;
    private JButton generateReportBtn;
    private JButton checkStudentRecord;
    private JButton logoutBtn;

    public AdminDashboard() {
        // Initialize components
        frame = new JFrame("Admin Dashboard");
        panel = new JPanel(new GridBagLayout());
        welcomeLabel = new JLabel("Welcome, Admin!");
        manageRoomsBtn = new JButton("Manage Hostel Rooms");
        manageApplicationsBtn = new JButton("Manage Student Hostel Applications");
        generateReportBtn = new JButton("Generate Reports");
        checkStudentRecord = new JButton("Check Studenet Record");
        logoutBtn = new JButton("Logout");

        // Add components to panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(welcomeLabel, gbc);
        gbc.gridy = 1;
        panel.add(manageRoomsBtn, gbc);
        gbc.gridy = 2;
        panel.add(manageApplicationsBtn, gbc);
        gbc.gridy = 3;
        panel.add(generateReportBtn, gbc);
        gbc.gridy = 4;
        panel.add(checkStudentRecord,gbc);
        gbc.gridy = 5;
        panel.add(logoutBtn, gbc);

        // Add action listeners
        manageRoomsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HostelRoomCURD();
            }
        });
        manageApplicationsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ManageStudentHostelApplication();
            }
        });
        generateReportBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new GenerateReport();
            }
        });
        
        checkStudentRecord.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CheckStudentRecord();
            }
        });
        
        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              frame.dispose();
              System.exit(0);  
            }
        });

        // Set frame properties
        frame.add(panel);
        frame.setSize(400, 320);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    public void setVisible(boolean value){
        
        frame.setVisible(value);
    }
    
    public static void main(String args[]){
        new AdminDashboard();
    }
}
