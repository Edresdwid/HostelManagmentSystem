
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

public class LoginScreen {

    private JFrame loginFrame;
    private JPanel loginPanel;
    private JLabel usernameLabel;
    private JTextField usernameTextField;
    private JLabel emailLabel;
    private JTextField emailTextField;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel errorLabel;
   // private ArrayList<User> users;

    public LoginScreen() {
        //this.users = users;
        loginFrame = new JFrame("Hostel Management System - Login");
        loginFrame.setPreferredSize(new Dimension(600, 300)); // Set the width and height of the frame
        loginPanel = new JPanel(new GridLayout(0, 1));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding to the panel
        usernameLabel = new JLabel("Username:");
        usernameTextField = new JTextField();
        usernameTextField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Add padding to the text field
        emailLabel = new JLabel("Email:      Admin(@admin.com)  Student(@Student.com)");
        emailTextField = new JTextField();
        emailTextField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        passwordField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Add padding to the password field
        loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(100, 30)); // Reduce the size of the login button
        errorLabel = new JLabel("");
        loginPanel.add(usernameLabel);
        loginPanel.add(usernameTextField);
        loginPanel.add(emailLabel);
        loginPanel.add(emailTextField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(Box.createRigidArea(new Dimension(0, 20))); // add space between text fields and button
        loginPanel.add(loginButton);
        loginPanel.add(errorLabel);
        loginFrame.add(loginPanel);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.pack();
        loginFrame.setVisible(true);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                File file = new File("users.txt");
                if (file.exists()) {
                    ArrayList<User> u = FileManager.readUsersFromFile();
                    String username = usernameTextField.getText();
                    String email = emailTextField.getText();
                    String password = new String(passwordField.getPassword());
                    User user = authenticate(username, email, password, u);
                    if (user != null) {
                        if (user instanceof Admin) {
                            loginFrame.dispose();
                            new AdminDashboard();
                        } else if (user instanceof Student) {
                            loginFrame.dispose();
                            new StudentDashboard();
                        } else {
                            errorLabel.setText("Invalid username or password.");
                        }
                    } else {

                        if (email.contains("@admin.com")) {
                            u.add(new Admin(username, email, password));
                            FileManager.writeUsersToFile(u);
                            loginFrame.dispose();
                            new AdminDashboard();
                        } else if (email.contains("@student.com")) {
                            u.add(new Student(username, email, password));
                            FileManager.writeUsersToFile(u);
                            loginFrame.dispose();
                            new StudentDashboard();
                        } else {
                            errorLabel.setText("Invalid username or password.");
                        }
                    }
                } else {
                    String username = usernameTextField.getText();
                    String email = emailTextField.getText();
                    String password = new String(passwordField.getPassword());
                    ArrayList<User> us = new ArrayList<>();
                    if (email.contains("@admin.com")) {
                        us.add(new Admin(username, email, password));
                        FileManager.writeUsersToFile(us);
                        loginFrame.dispose();
                        new AdminDashboard();
                    } else if (email.contains("@student.com")) {
                        us.add(new Student(username, email, password));
                        FileManager.writeUsersToFile(us);
                        loginFrame.dispose();
                        new StudentDashboard();
                    } else {
                        errorLabel.setText("Invalid username or password.");
                    }
                }

            }
        });
    }

    private User authenticate(String username, String email, String password, ArrayList<User> u) {
        for (User user : u) {
            if (user.getName().equalsIgnoreCase(username) && user.getEmail().equalsIgnoreCase(email) && user.getPassword().equalsIgnoreCase(password)) {
                return user;
            }
        }
        return null;
    }

    public static void main(String args[]) {

        new LoginScreen();
    }
}
