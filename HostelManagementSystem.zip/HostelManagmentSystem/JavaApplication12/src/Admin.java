public class Admin extends User {
    public Admin(String name, String email, String password) {
        super(name, email, password);
    }

    @Override
    public void login() {
        // Admin login logic
    }

    @Override
    public void logout() {
        // Admin logout logic
    }
}